# 稳优 StableTune
适用于win10/11的系统优化软件

---

# 稳优 StableTune 中文使用说明

稳优 StableTune 是一个面向 Windows 10/11 x64 的可回滚系统优化原型。
程序使用 PowerShell 7 和 WPF，提供 38 项固定规则、执行前快照、历史记录、
单项恢复和恢复全部功能。

当前说明对应版本：`0.1.9.1`

推荐发布包：

```text
dist/StableTune-prototype-v0.1.9.1-20260920.zip
```

本版本将程序正式更名为“稳优 StableTune”，统一更新启动器、PowerShell 模块、
Qt 可执行文件、界面标题和发布包名称。内部函数、环境变量以及
`%LOCALAPPDATA%\FelixOptimizer` 状态目录继续兼容，因此已有历史、快照和回滚
记录仍可在新版本中读取。全部 38 项规则、安全边界和执行行为保持不变。

## 一、怎样进入程序

### 方法 1：双击进入图形界面

1. 打开 稳优 StableTune 所在目录。
2. 双击 `Start-StableTune.cmd`。
3. 启动器会立即请求管理员权限。请在 UAC 提示中选择“是”。
4. 获得管理员权限后，启动器会检测 PowerShell 7，然后打开 WPF 窗口。
5. 启动器会显示 `Administrator privileges: Yes`。
6. 程序默认进入“系统状态”页面。
7. 在左侧选择“系统状态”“优化分类”“历史记录”“恢复中心”“日志”“设置”
   或“关于我们”。
8. 进入“优化分类”后，可勾选单项或使用“全选”“全不选”“选择适用项”，再
   使用“预检所选”“执行所选”，也可对单项执行“预检”“执行”或“恢复”。

如果拒绝 UAC 或启动失败，启动器会保留命令行窗口并显示错误，不会立即消失。
请把窗口中的错误信息截图后反馈。

不要直接双击 `StableTune.ps1`。Windows 可能使用 PowerShell 5.1
打开它，而本程序需要 PowerShell 7。

### 方法 2：从 PowerShell 7 终端进入

先进入程序目录，例如：

```powershell
cd "<解压后的项目目录>"
```

然后启动图形界面：

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\StableTune.ps1
```

也可以显式指定界面模式：

```powershell
pwsh -NoProfile -File .\StableTune.ps1 -Ui
```

### 方法 3：只进入命令行模式

查看全部规则：

```powershell
pwsh -NoProfile -File .\StableTune.ps1 -Command List
```

只读检查当前系统状态，不会修改系统：

```powershell
pwsh -NoProfile -File .\StableTune.ps1 -Command Audit
```

预检某一项，不会修改系统：

```powershell
pwsh -NoProfile -File .\StableTune.ps1 -Command DryRun -RuleId power-plan
```

执行、恢复和恢复全部：

```powershell
pwsh -NoProfile -File .\StableTune.ps1 -Command Apply -RuleId power-plan -AcceptRisk
pwsh -NoProfile -File .\StableTune.ps1 -Command Restore -HistoryId <操作ID>
pwsh -NoProfile -File .\StableTune.ps1 -Command RestoreAll
```

## 二、双击后窗口立即消失怎么办

先使用修正版启动器：

```text
Start-StableTune.cmd
```

它会依次查找以下位置的 PowerShell 7：

- 系统 `PATH`
- `%ProgramFiles%\PowerShell\7`
- `%ProgramFiles(x86)%\PowerShell\7`
- `%LOCALAPPDATA%\Programs\PowerShell\7`
- `%LOCALAPPDATA%\Microsoft\WindowsApps`
- 当前机器可用的 Codex PowerShell 运行时

如果全部位置都没有找到，启动器会停住并显示安装命令。

检查 PowerShell 7 是否已安装：

```powershell
pwsh --version
```

安装 PowerShell 7：

```powershell
winget install --id Microsoft.PowerShell --source winget
```

安装完成后关闭旧窗口，再重新双击修正版启动器。

## 三、界面中的主要区域

- `系统状态`：查看系统、权限、当前电源方案、历史操作和还原点状态。
- `优化分类`：按分类查看规则、风险颜色和本机适用性；支持全选、部分选择、
  批量预检、批量执行和单项恢复。规则说明、证据和风险内容可在右侧独立滚动。
- `历史记录`：查看每次操作的时间、状态、结果和是否需要重启。
- `恢复中心`：恢复所选操作，按时间逆序执行“恢复全部”，检查当前回滚能力，
  或打开 Windows 系统还原。
- `设置`：切换双重保险或独立快照模式，打开状态目录，或处理历史和隔离区。
- `关于我们`：查看项目仓库、适用性核验日期、VTD/HVCI 与 ACE 检测结果、
  安全边界和防崩溃保险说明。

高级项会要求二次确认。双重保险模式下，每次执行前都会检查独立快照是否可写，
并检查 Windows 系统保护是否返回可用还原点；没有可用还原点时会在提权环境中
尝试创建。关闭开关后进入独立快照模式：程序不再要求系统还原点，但独立快照
不可用时仍会阻止执行。单项恢复默认使用独立快照精确回滚；恢复点存在时仍
提供系统级兜底。

## 四、本机适用性、批量处理与防崩溃保险

每项规则都会返回以下四种状态之一：

- `适用本机`：本机硬件和系统条件满足技术要求。
- `有条件适用`：本机可以使用，但存在功耗、兼容性或使用场景条件，需要确认。
- `不适用本机`：已确认本机条件不满足要求，程序禁止执行。
- `无法判断`：缺少可靠检测结果。程序按失败关闭处理，同样禁止执行。

适用性判断会读取 Windows 版本、系统架构、CPU/GPU、WDDM、内存、系统盘类型、
文件系统、打印设备和域状态。技术结论已根据微软官方文档、IETF RFC、DMTF
SMBIOS 等公开资料进行交叉核验，并固化在程序中；程序运行时不依赖互联网。
这里的“高可靠性”是指多来源核验、未知即阻断和可审计，不是对所有第三方
硬件组合作绝对保证。

防崩溃保险会在实际修改前创建持久恢复事务，并注册启动恢复入口。若修改期间
蓝屏或异常关机，下次启动会识别异常关机事件并自动恢复原快照；需要重启的
优化只有在正常重启后才确认保留。自动恢复连续失败三次后会转为人工处理，
不会静默放过。

批量执行按列表顺序处理。需要单独选择目标的规则会自动跳过；中途失败时，
程序逆序回滚本次已经成功的规则。

## 五、内存与时序识别

内存页会尽力显示整机容量、模块数量、单条容量、额定频率、配置频率、电压、
内存代际、插槽、厂家、料号和序列号。识别顺序为
`Win32_PhysicalMemory`、旧版 WMI，以及 Windows 原生可见内存总量三层兜底。

Windows 公共 API 不公开 SPD 时序。程序不会猜测或伪造 CL、tRCD、tRP、tRAS、
CR。如需在界面中显示已核验时序，可在状态目录创建
`memory-timings.json`，从 CPU-Z 或 BIOS 核实后填写：

```json
{
  "modules": [
    {
      "deviceLocator": "DIMM 0",
      "casLatency": 40,
      "trcd": 40,
      "trp": 40,
      "tras": 96,
      "commandRate": 2,
      "source": "CPU-Z verified"
    }
  ]
}
```

模块可通过 `deviceLocator`、`partNumber` 或 `serialNumber` 匹配。没有可用模块
信息时，程序仍会显示 Windows 可见物理内存，并明确标注插槽或频率不可用。

## 六、规则说明

当前版本共有 38 项可回滚规则。每项在“优化分类”详情区都会显示：

- 优点
- 缺点
- 执行建议
- 可能出现的后果
- 适用范围
- 操作系统、CPU 品牌、CPU 系列、GPU 品牌、显卡驱动、内存、存储和设备条件
- 风险等级和是否需要重启

如果某项不依赖特殊硬件，程序会明确标注“通用”。条件项会说明它依赖的
CPU、GPU、SSD、网卡、驱动或用户选择。

低风险项显示绿色字体，高风险项显示红色字体。新增的主要规则包括：

- 禁用处理器核心停放
- 禁用处理器空闲状态
- 修复异类调度与性能提升模式漂移
- 降低腾讯 ACE CPU 优先级
- 设置指定游戏 EXE 的 CPU 优先级
- 关闭鼠标指针加速
- 启用 Windows 游戏模式
- 关闭后台游戏录制
- 启用 GPU 硬件加速调度
- 关闭多平面覆盖 MPO
- 关闭指定程序的全屏优化
- 关闭所选网卡 Nagle 合并
- 关闭所选网卡 NetBIOS
- 关闭所选网卡中断节流
- 确保 SSD TRIM 已启用
- 关闭 NTFS 最后访问时间更新
- 禁用 SysMain
- 禁用 Windows Search 索引
- 禁用打印后台处理服务
- 禁用诊断遥测服务
- 减少系统界面动画
- 取消登录启动延迟

## 七、状态和历史保存在哪里

运行数据保存在：

```text
%LOCALAPPDATA%\FelixOptimizer
```

历史记录采用追加式 JSONL。快照和隔离文件按操作 ID 保存。恢复操作不会删除
历史，也不会自动永久删除隔离区内容。

## 八、安全说明

- 每项实际修改前都会尽力保存原值快照。
- 应用后会重新读取并验证结果，验证失败时尝试自动回滚。
- “恢复全部”只处理尚未恢复的成功操作。
- 如果当前系统值已被外部修改，默认跳过冲突项，不覆盖未知变化。
- 独立完整快照用于逐项精确恢复，Windows 系统还原点用于可选的系统级第二保险。
- 双重保险模式下，每次实际修改前必须同时通过快照写入检查与系统还原点检查。
- 独立快照模式下，每次实际修改前仍必须通过快照写入检查，否则禁止执行。
- 快照、历史和回滚日志会记录对应系统还原点编号。
- 恢复中心提供“打开系统还原”，便于在独立快照恢复失败时使用第二保险。
- 修改前会创建防崩溃恢复事务；异常关机后会自动恢复未确认的修改。
- 临时文件清理采用隔离方式，恢复时会移回原路径。
- 程序不包含代码签名、自动更新、联网服务、MSR/RwEverything、反作弊绕过，
  也不会自动关闭 Windows Defender 或 Windows Update。
- VTD/HVCI 只作为安全兼容状态显示；程序不会自动关闭内存完整性、VBS、
  Defender 或相关虚拟化安全功能。
- 首次验证高级规则时，建议在 Windows 10/11 一次性虚拟机中进行。

## 九、不自动执行的项目

以下内容只在高级硬件建议中出现，但首版不会自动修改：

- BIOS 中的 PBO、Curve Optimizer、电压、内存 XMP/EXPO、PCIe 链路宽度或速率。
- AMD Ryzen 7 9800X3D 等特定 CPU 的超频和降压参数。
- RwEverything/MSR 类底层读写。
- 绕过、篡改或规避游戏反作弊。
- 永久删除文件。
- 自动关闭 Windows Defender 或 Windows Update。

这些项目要么依赖主板和内存型号，要么恢复边界不可靠，要么违反安全边界。

## 十、运行测试

```powershell
pwsh -NoProfile -File .\tests\Run-Tests.ps1
```

集成测试不会主动修改真实系统设置。
